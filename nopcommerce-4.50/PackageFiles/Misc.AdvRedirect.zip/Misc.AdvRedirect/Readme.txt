1. 'Nop.Plugin.Misc.AdvRedirect' directory contains source code.
2. 'Misc.AdvRedirect' contains binaries. Just drop it into \Plugins directory on your server.